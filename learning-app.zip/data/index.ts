export const ageSettings = [
  { slug: '1-2', name: '1-2 tahun' },
  { slug: '2-3', name: '2-3 tahun' },
];
