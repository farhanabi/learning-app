"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 5483:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/naflibox-logo.6a30a661.png","height":636,"width":2376,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAATUlEQVR4nAFCAL3/AeDNs7X69eqyCzlip/7n4SMAAQMHBQUF58LBweFWV1cAAeGzTrv+GF78odgZZzQO6BX/AgYX7+7u/r++vtQQEBD6ZJIhaPRQoHUAAAAASUVORK5CYII="});

/***/ }),

/***/ 4794:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Index),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "@headlessui/react"
const react_namespaceObject = require("@headlessui/react");
// EXTERNAL MODULE: external "@heroicons/react/solid"
var solid_ = __webpack_require__(1143);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/Page.tsx
var Page = __webpack_require__(6000);
;// CONCATENATED MODULE: ./data/index.ts
const ageSettings = [
    {
        slug: '1-2',
        name: '1-2 tahun'
    },
    {
        slug: '2-3',
        name: '2-3 tahun'
    }, 
];

// EXTERNAL MODULE: ./lib/api.ts
var api = __webpack_require__(4390);
// EXTERNAL MODULE: ./public/images/naflibox-logo.png
var naflibox_logo = __webpack_require__(5483);
// EXTERNAL MODULE: ./utils/classNames.ts
var classNames = __webpack_require__(2478);
;// CONCATENATED MODULE: ./pages/index.tsx











function Index({ categories  }) {
    const { 0: selectedAge , 1: setSelectedAge  } = (0,external_react_.useState)(ageSettings[0].slug);
    const { 0: selectedCategory , 1: setSelectedCategory  } = (0,external_react_.useState)(categories[0]?.slug);
    return(/*#__PURE__*/ jsx_runtime_.jsx(Page/* default */.Z, {
        title: "Naflibox",
        description: "Karena Pendidikan dimulai dari Rumah",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "relative bg-gray-50 mx-auto max-w-sm h-full min-h-screen",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "p-4 w-40",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                        src: naflibox_logo/* default */.Z
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "max-w-xs mx-auto py-0",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-md mb-4 px-4",
                            children: "Bunda ingin bermain aktifitas umur berapa?"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_namespaceObject.RadioGroup, {
                            value: selectedAge,
                            onChange: setSelectedAge,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(react_namespaceObject.RadioGroup.Label, {
                                    className: "sr-only",
                                    children: "Age Settings"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "bg-white rounded-md space-y-2",
                                    children: ageSettings.map((setting)=>/*#__PURE__*/ jsx_runtime_.jsx(react_namespaceObject.RadioGroup.Option, {
                                            value: setting.slug,
                                            className: ({ checked  })=>(0,classNames/* default */.Z)(checked && 'z-10', 'flex relative items-center bg-cyan-400 border-cyan-400 border px-4 py-2 cursor-pointer rounded-2xl focus:outline-none')
                                            ,
                                            children: ({ active , checked  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                            className: (0,classNames/* default */.Z)(checked ? 'bg-yellow-400 border-yellow-400' : 'bg-white border-gray-300', active ? 'ring-2 ring-offset-2 ring-yellow-400 border-yellow-400' : '', 'h-6 w-6 mt-0.5 cursor-pointer rounded-lg border flex items-center justify-center'),
                                                            "aria-hidden": "true"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "w-full ml-3 flex flex-col text-right",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(react_namespaceObject.RadioGroup.Label, {
                                                                as: "span",
                                                                className: "block text-lg text-stone-600 font-semibold",
                                                                children: setting.name
                                                            })
                                                        })
                                                    ]
                                                })
                                        }, setting.name)
                                    )
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-md my-4 px-4",
                            children: "Bunda ingin mempelajari kategori apa?"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_namespaceObject.RadioGroup, {
                            value: selectedCategory,
                            onChange: setSelectedCategory,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(react_namespaceObject.RadioGroup.Label, {
                                    className: "sr-only",
                                    children: "Category"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "mx-auto grid grid-cols-3 gap-2",
                                    children: categories.length > 0 && categories.map((category)=>/*#__PURE__*/ jsx_runtime_.jsx(react_namespaceObject.RadioGroup.Option, {
                                            value: category.slug,
                                            children: ({ checked  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: (0,classNames/* default */.Z)(checked && category.isAvailable && `ring-4 ring-yellow-400`, `relative w-24 h-24 justify-center border rounded-3xl cursor-pointer sm:flex focus:outline-none`),
                                                            style: {
                                                                backgroundColor: category.isAvailable ? category.color : '#AAAAAA'
                                                            },
                                                            "aria-hidden": "true",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: (0,classNames/* default */.Z)('absolute -left-1 -top-1 w-20 h-20', !category.isAvailable && 'grayscale'),
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                                    src: category.image.url,
                                                                    alt: category.name
                                                                })
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(react_namespaceObject.RadioGroup.Label, {
                                                            as: "p",
                                                            className: "w-full font-medium text-center text-stone-600 text-md",
                                                            children: category.name
                                                        })
                                                    ]
                                                })
                                        }, category.slug)
                                    )
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                    href: `/kategori/${selectedCategory}/${selectedAge}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                            className: "absolute bottom-2 right-2 w-max flex gap-x-2 justify-between items-center mt-4 py-2 px-8 border border-transparent rounded-xl shadow-lg text-xl font-medium text-black bg-yellow-300 hover:bg-yellow-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500",
                            children: [
                                "Pilih ide",
                                /*#__PURE__*/ jsx_runtime_.jsx(solid_.ArrowRightIcon, {
                                    className: "h-6 w-6"
                                })
                            ]
                        })
                    })
                })
            ]
        })
    }));
};
async function getStaticProps() {
    const categories = await (0,api/* getCategories */.CP)() || [];
    return {
        props: {
            categories
        },
        revalidate: 60
    };
}


/***/ }),

/***/ 2478:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ classNames)
/* harmony export */ });
function classNames(...classes) {
    return classes.filter(Boolean).join(' ');
};


/***/ }),

/***/ 1143:
/***/ ((module) => {

module.exports = require("@heroicons/react/solid");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [190,676,664,675,239], () => (__webpack_exec__(4794)));
module.exports = __webpack_exports__;

})();