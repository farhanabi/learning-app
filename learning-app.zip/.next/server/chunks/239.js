"use strict";
exports.id = 239;
exports.ids = [239];
exports.modules = {

/***/ 6000:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const Page = ({ title , description , children  })=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: description
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            children
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Page);


/***/ }),

/***/ 4390:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CP": () => (/* binding */ getCategories),
/* harmony export */   "fj": () => (/* binding */ getCategoryBySlug),
/* harmony export */   "WY": () => (/* binding */ getVideos),
/* harmony export */   "H6": () => (/* binding */ getVideoBySlug),
/* harmony export */   "a$": () => (/* binding */ registerUser)
/* harmony export */ });
/* unused harmony export getCategoriesSlug */
async function fetchAPI(query, { variables  } = {}) {
    const res = await fetch(`${"http://naflibox.herokuapp.com"}/graphql`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            query,
            variables
        })
    });
    const json = await res.json();
    if (json.errors) {
        console.error(json.errors);
        throw new Error('Failed to fetch API');
    }
    return json.data;
}
async function getCategories() {
    const data = await fetchAPI(`
    query Categories($where: JSON){
      categories(where: $where) {
        id
        slug
        name
        image {
          url
        }
        isAvailable
        color
      }
    }
  `);
    return data?.categories;
}
async function getCategoryBySlug(slug = undefined) {
    const data = await fetchAPI(`
    query Categories($where: JSON){
      categories(where: $where) {
        slug
        name
        image {
          url
        }
        isAvailable
        color
      }
    }
  `, {
        variables: {
            where: {
                slug
            }
        }
    });
    return data?.categories[0];
}
async function getCategoriesSlug() {
    const data = await fetchAPI(`
    query Categories($where: JSON){
      categories(where: $where) {
        slug
      }
    }
  `);
    return data?.categories;
}
async function getVideos(where = {}) {
    const data = await fetchAPI(`
    query getVideos($where: JSON){
      videos(where: $where) {
        slug
        title
        items
        needRegistration
        minAge
        maxAge
        category {
          id
          slug
          name
          image {
              url
          }
        }
        youtubeUrl
      }
    }
  `, {
        variables: {
            where
        }
    });
    return data?.videos;
}
async function getVideoBySlug(slug = undefined) {
    const data = await fetchAPI(`
    query getVideoBySlug($where: JSON){
      videos(where: $where) {
        slug
        title
        items
        needRegistration
        objective
        minAge
        maxAge
        category {
          id
          slug
          name
          color
          image {
              url
          }
        }
        youtubeUrl
      }
    }
  `, {
        variables: {
            where_contains: {
                slug
            }
        }
    });
    return data?.videos[0];
}
async function registerUser(data) {
    const mutation = await fetchAPI(`
    mutation {
      register(
        input: {
          username: "${data.username}"
          email: "${data.email}"
          password: "${data.password}"
        }
      ) {
        jwt
        user {
          username
          email
        }
      }
    }
    `);
    return mutation?.register;
}


/***/ })

};
;