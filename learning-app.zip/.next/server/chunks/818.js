"use strict";
exports.id = 818;
exports.ids = [818];
exports.modules = {

/***/ 4818:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "_": () => (/* binding */ useLocalStorage)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./hooks/useMount.ts

/**
 * Run a function when a component is mounted.
 *
 * @param callback function to be executed
 */ function useMount(callback) {
    (0,external_react_.useEffect)(callback, []);
}

;// CONCATENATED MODULE: ./hooks/useLocalStorage.ts


/**
 * Modified `useState` hook that syncs with localStorage.
 *
 * @param key
 * @param initialValue
 * @param options
 *
 * @see https://react-hooks-library.vercel.app/core/useLocalStorage
 */ function useLocalStorage(key, initialValue, options) {
    const { 0: storedValue , 1: setStoredValue  } = (0,external_react_.useState)(initialValue);
    const { deserialize =JSON.parse , serialize =JSON.stringify  } = options || {};
    useMount(()=>{
        try {
            const item = localStorage.getItem(key);
            item && setStoredValue(deserialize(item));
        } catch (error) {
            console.error(error);
        }
    });
    const setValue = (0,external_react_.useCallback)((value)=>{
        try {
            localStorage.setItem(key, serialize(value));
            setStoredValue(value);
        } catch (error) {
            console.error(error);
        }
    }, [
        key,
        serialize
    ]);
    return [
        storedValue,
        setValue
    ];
}


/***/ })

};
;